sudo systemctl start bluetooth

sleep 1

# run the program bluez
echo -e 'power on\nagent on\ndiscoverable on\npairable on\nquit\t'| bluetoothctl

