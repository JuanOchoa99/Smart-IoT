
from collections import OrderedDict 
import json 
import os 
import argparse 
import sys 
from datetime import date 
from datetime import datetime


#today = date.today()
#now = datetime.now()
#print (today)
#print (now)
attributes ={
"sensor-id" : "-",
"node-id"   : "-",
"gate-id"   : "-",
"date"      : "-",
"value"     : "-",
"magnitude" : "-",
"gps"       : "-",
"network-id": "-",
"protocol"  : "-"
}


attributes2 ={
"2sensor-id" : "-",
"2node-id"   : "-",
"2gate-id"   : "-",
"2date"      : "-",
"2value"     : "-",
"2magnitude" : "-",
"2gps"       : "-",
"2network-id": "-",
"2protocol"  : "-"
}





#print y
#y=json.loads(x)


#ayuda
parser = argparse.ArgumentParser()
parser.add_argument("-p"   , help=":sending protocol")
parser.add_argument("-n"   , help=":node address")
parser.add_argument("-s"   , help=":sensor name")
parser.add_argument("-v"   , help=":value")
parser.add_argument("-m"   , help=":sensor magnitude")
parser.add_argument("-net" , help=":network name")
parser.add_argument("-g"   , help=":gateway address")
parser.add_argument("-gps" , help=":global positioning system")
parser.add_argument("-d"   , help=":date")



args= parser.parse_args()

if args.p=="zigbee":
        if args.p:
	        print "sending protocol:",args.p
	        attributes2["2protocol"]=args.p
        if args.n:
	        print "node address:",args.n
	        attributes2["2node-id"]=args.n
        if args.s:
	        print "sensor name is:",args.s
	        attributes2["2sensor-id"]= args.s

        if args.v:
	        print "value:",args.v
	        attributes2["2value"]= args.v

        if args.m:
	        print "magnitude:",args.m
	        attributes2["2magnitude"]=args.m

        if args.net:
                print "network name:",args.net
                attributes2["2network-id"]=args.net

        if args.g:
                print "gateway address:",args.g
                attributes2["2gate-id"]=args.g

        if args.gps:
                print "location:",args.gps
                attributes2["2gps"]=args.gps

        if args.d:
                print "date:",args.d
                attributes2["2date"]=args.d
else:
        if args.p:
	        print "sending protocol:",args.p
	        attributes["protocol"]=args.p
        if args.n:
	        print "node address:",args.n
	        attributes["node-id"]=args.n
        if args.s:
	        print "sensor name:",args.s
	        attributes["sensor-id"]= args.s

        if args.v:
	        print "value:",args.v
	        attributes["value"]= args.v

        if args.m:
	        print "magnitude:",args.m
	        attributes["magnitude"]=args.m

        if args.net:
                print "network name:",args.net
                attributes["network-id"]=args.net

        if args.g:
                print "gateway address is:",args.g
                attributes["gate-id"]=args.g

        if args.gps:
                print "location:",args.gps
                attributes["gps"]=args.gps

        if args.d:
                print "date:",args.d
                attributes["date"]=args.d

datajson = json.dumps(attributes, indent=4,separators=(',',':'),sort_keys=True)
datajson2 = json.dumps(attributes2, indent=4,separators=(',',':'),sort_keys=True)

if args.p == "bluetooth":
	send= "python blue_send.py -json '%s'" % datajson
#	send = "mosquitto_pub -h 192.168.1.79 -t bluetooth -m '%s'" % datajson
        os.system(send)

if args.p == "zigbee":
	send = "python xbee_send.py -json '%s'" % datajson2
        os.system(send)


if args.p == "wifi":
	send = "mosquitto_pub -h 192.168.4.1 -t wifi -m '%s'" % datajson
	os.system(send)


#send= "python prueb.py -data '%s'" % datajson
#os.system(send)
#print datajson


#x["id_sensor"]="Temperatura"


#allsites=[x]
#sort_order = ['id_sensor', 'id_nodo', 'id_gatew', 'fecha','valor','Magnitud','GPS']
#allsites_ordered = [OrderedDict(sorted(item.iteritems(), key=lambda (k, v): sort_order.index(k))) 
#			for item in allsites]

#matriz= json.dumps(x, indent=4, separators=(',', ': '))
#print matriz

#mensaje = "mosquitto_pub -h 172.17.27.170 -t Linux -m '%s'" % matriz
#os.system(mensaje)

