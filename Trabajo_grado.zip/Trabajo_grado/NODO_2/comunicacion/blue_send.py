from collections import OrderedDict
import json
import os
import argparse
import sys
import bluetooth

def Blue_send():

    with open('conf_l.json') as file:
        datajson = json.load(file)

    for net in datajson['interfaces']:
        if net['type'] == 'blue':
            mac_address = net['mac']
            port = net['port']



    parser= argparse.ArgumentParser()
    parser.add_argument("-json",help="message to send")
    args= parser.parse_args()


    bd_addr = mac_address
    port    = port
    sock    = bluetooth.BluetoothSocket( bluetooth.RFCOMM )
    sock.connect((bd_addr, port))
    mensaje= args.json
    sock.send(mensaje)
    sock.close()

