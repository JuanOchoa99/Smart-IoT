from gpiozero import LED
import json
from time import sleep
import paho.mqtt.subscribe as subscribe

electrovalve = LED(21)

# with open('conf_l.json') as file:
#     data = json.load(file)
#     for actuator in data['actuators']:
#         if actuator['type'] == 'asp':
#             act_anable = True
#         else:
#             act_anable = False


# msg = subscribe.simple("act_l", hostname="192.168.4.1")
# datos = msg.payload
# datum = datos.decode('ASCII')
# datajson = json.loads(datum)

# for actor in datajson['actuators']:
#     if actor['actuator-id'] == 'Lawn-sprinkler':
#         # if act_anable == True:

while True:
    electrovalve.on()
    sleep(1)
    electrovalve.off()
    sleep(1)


