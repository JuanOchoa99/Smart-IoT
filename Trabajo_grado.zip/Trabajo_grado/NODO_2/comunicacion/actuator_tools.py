from gpiozero import LED
import json
from time import sleep
import paho.mqtt.subscribe as subscribe
from datetime import date, datetime, time, timedelta


    # if sensor['actuator-id'] == 'RGB': # para revisar cuando se instalen los RGB
    #     for orden in actor['order']:
    #         if orden['red'] == on:
    #             RGB = True


class Actuator():
    def __init__(self,typ,sta,ide,valve):
        self.__ide = ide
        self.__sta = sta
        self.__typ = typ
        self.__valve = valvelocal

    def getIde(self):
        return self.__ide

    def setIde(self,ide):
        self.__ide=ide    
    
    def getTyp(self):
        return self.__typ
    
    def setTyp(self,typ):
        self.__typ=typ      
    
    def getSta(self):
        return self.__sta
    
    def setSta(self,sta):
        self.__sta=sta

    def getValve(self):
        return self.__valve
    
    def setValve(self,valve):
        self.__valve=valve

    def toJason2(self):
        self.__attributes = {"type" : "-","actuator-id" : "-","state":"-","valvula":"-"}
        self.__attributes["type"]=self.getTyp()
        self.__attributes["actuator-id"]=self.getIde()
        self.__attributes["state"]=self.getSta()
        self.__attributes["valvula"]=self.getValve()
        self.__datajson = json.dumps(self.__attributes, indent=4,separators=(',',':'),sort_keys=False)
        return self.__datajson

    def __str__(self):           
        return self.toJason2()

class ReadActuator():
    def __init__(self):
        self.__actuators=[]

    
    def create_electro(self,typ):
        global valvula
        typ = typ
        state = lectura_estadoAc(typ)
        ide = lectura_ideAc(typ)
        valve = valvula
        if state == 'active':
            return Actuator(typ,state,ide,valve).toJason2()  

    def createActuator(self,actuatorType):
        if actuatorType == 'asp':              
            return self.create_electro('asp')


def lectura_estadoAc(tipo):

    with open('conf_l.json') as file:
        datajson = json.load(file)
        for actuator in datajson['actuators']:
            if actuator['type'] == tipo:
                return actuator['state']


def lectura_ideAc(tipo):

    with open('conf_l.json') as file:
        datajson = json.load(file)
        for actuator in datajson['actuators']:
            if actuator['type'] == tipo:
                return actuator['actuator-id']



def envio_sta_l():

    hoy= datetime.today()
    formatdate= "%x-%X"
    now = hoy.strftime(formatdate)
    nuevo_json = {}
    nuevo_json['node-id']= nodeid
    nuevo_json['date'] = now
    nuevo_json['actuators'] =[]

    with open('conf_l.json') as file:
        datajson = json.load(file)
        for actuator in datajson['actuators']:
            estacion_act = ReadActuator().createActuator(actuator['type'])
            if estacion_act != None:
                nuevo_json['actuators'].append(json.loads(estacion_act))             
                print(json.dumps(nuevo_json, indent=4))
                # aqui va el envio de sta_l

############ Proceso del actuador ###################

nodeid = 'estacion_2'
electrovalve = LED(21)
valvula = 'off'

while True:

    elecvalve = False
    msg = subscribe.simple("act_l", hostname="192.168.4.1")
    datos = msg.payload
    datum = datos.decode('ASCII')
    datajson = json.loads(datum)

    if datajson['node-id'] == 'estacion_2':
        if datajson['request'] == 'act':

            for actor in datajson['actuators']:
                if actor['actuator-id'] == 'Lawn-sprinkler':
                    #print(actor['order'])
                    if actor['order'] == 'on':
                        valvula = 'on'
                        electrovalve.on()                
                        
                    elif actor['order'] == 'off':
                        valvula = 'off'
                        electrovalve.off()
                
        
        #print(datajson['request'])
        if datajson['request'] == 'info':
            envio_sta_l()



