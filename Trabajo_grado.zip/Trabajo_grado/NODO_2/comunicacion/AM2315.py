import board
import busio
import adafruit_am2320
import math
import traceback

i2c = busio.I2C(board.SCL, board.SDA)
sensor = adafruit_am2320.AM2320(i2c)

temperature = sensor.temperature

def tem_data():
    temperature = sensor.temperature
    return "{0}C".format(temperature)

def hum_data():
    humidity = sensor.relative_humidity
    return '{0}%'.format(humidity)


