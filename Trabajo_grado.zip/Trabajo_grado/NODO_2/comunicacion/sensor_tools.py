import json
from time import sleep
from datetime import date, datetime, time, timedelta
import paho.mqtt.subscribe as subscribe
import paho.mqtt.client as mqtt
import sys
import os
import time
import paho.mqtt.publish as publish
import calendar
from gpiozero import MCP3008
from gpiozero import Button
import board
import busio
import adafruit_am2320
import math
import traceback
from air_speed import speed_data
from pluviometer import rain_data
from AM2315 import tem_data, hum_data

adc1 = MCP3008 (channel=1)
adc0 = MCP3008 (channel=0)
############### Clases #########################
humi = False
radi = False
velo = False
dire = False
pluv = False
temp = False


class SensorEst():
    def __init__(self,typ,ide,sta,stu): #stu = status
        self.__ide=ide
        self.__typ=typ
        self.__stu=stu
        self.__sta = sta
    
    def getIde(self):
        return self.__ide
    
    def setIde(self,ide):
        self.__ide=ide    
    
    def getTyp(self):
        return self.__typ
    
    def setTyp(self,typ):
        self.__typ=typ      
    
    def getSta(self):
        return self.__sta
    
    def setSta(self,sta):
        self.__sta=sta   

    def getStu(self):
        return self.__stu
    
    def setMag(self,stu):
        self.__stu=stu

        
    def toJason2(self):
        self.__attributes = {"type" : "-","sensor-id" : "-","state" : "-","status":"-"}
        self.__attributes["type"]=self.getTyp()
        self.__attributes["sensor-id"]=self.getIde()
        self.__attributes["state"]=self.getSta()
        self.__attributes["status"]=self.getStu()
        self.__datajson = json.dumps(self.__attributes, indent=4,separators=(',',':'),sort_keys=False)
        return self.__datajson
    
    def __str__(self):           
        return self.toJason2()

class CreateState():
    def __init__(self):
        self.__sensors=[]
    
    
    def state_temp(self,typ):
        global am2315t
        typ = typ
        state = lectura_estado(typ)
        ide = lectura_ide(typ)
        status = am2315t
        return SensorEst(typ,ide,state,status).toJason2()
    
    def state_hum(self,typ):
        global am2315h
        typ = typ
        state = lectura_estado(typ)
        ide = lectura_ide(typ)
        status = am2315h
        return SensorEst(typ,ide,state,status).toJason2()

    def state_rad(self,typ):
        global radia
        typ = typ
        state = lectura_estado(typ)
        ide = lectura_ide(typ)
        status = radia
        return SensorEst(typ,ide,state,status).toJason2()

    def state_plu(self,typ):
        global pluvio
        typ = typ
        state = lectura_estado(typ)
        ide = lectura_ide(typ)
        status = pluvio
        return SensorEst(typ,ide,state,status).toJason2()

    def state_wdirec(self,typ):
        global wdirec
        typ = typ
        state = lectura_estado(typ)
        ide = lectura_ide(typ)
        status = wdirec
        return SensorEst(typ,ide,state,status).toJason2()

    def state_wspeed(self,typ):
        global wspeed
        typ = typ
        state = lectura_estado(typ)
        ide = lectura_ide(typ)
        status = wspeed
        return SensorEst(typ,ide,state,status).toJason2()

    def createSensorState(self,sensorType):
        if sensorType == 'tem':            
            return self.state_temp('tem') # depende del archivo de entrada
        elif sensorType == 'hum':
            return self.state_hum('hum') 
        elif sensorType == 'vel':
            return self.state_wspeed('vel') 
        elif sensorType == 'dir':
            return self.state_wdirec('dir')
        elif sensorType == 'plu':
            return self.state_plu('plu') 
        elif sensorType == 'rad':
            return self.state_rad('rad')
#------------------------------------------------



class Sensor():
    def __init__(self,typ,ide,mag,val,sta):
        self.__ide=ide
        self.__typ=typ
        self.__mag=mag
        self.__val=val
        self.__sta = sta
    
    def getIde(self):
        return self.__ide
    
    def setIde(self,ide):
        self.__ide=ide    
    
    def getTyp(self):
        return self.__typ
    
    def setTyp(self,typ):
        self.__typ=typ      
    
    def getSta(self):
        return self.__sta
    
    def setSta(self,sta):
        self.__sta=sta   

    def getMag(self):
        return self.__mag
    
    def setMag(self,mag):
        self.__mag=mag
    
    def getVal(self):
        return self.__val
    
    def setVal(self,val):
        self.__val=val
        
    def toJason(self):
        self.__attributes = {"type" : "-","sensor-id" : "-","value" : "-", "magnitude" : "-","state":"-"}
        self.__attributes["type"]=self.getTyp()
        self.__attributes["sensor-id"]=self.getIde()
        self.__attributes["value"]=self.getVal()
        self.__attributes["magnitude"]=self.getMag()
        self.__attributes["state"]=self.getSta()
        self.__datajson = json.dumps(self.__attributes, indent=4,separators=(',',':'),sort_keys=False)
        return self.__datajson
    
    def __str__(self):           
        return self.toJason()


class ReadSensor():
    def __init__(self):
        self.__sensors=[]
    
    
    def create_temp(self,typ):
        global temperature
        global am2315t
        typ = typ
        state = lectura_estado(typ)
        ide = lectura_ide(typ)
        mag = 'Celsius'
        if state == 'active' and temp == True:
            am2315t = 'on'
            value = tem_data()          
            return Sensor(typ,ide,mag,value,state).toJason()

    def create_hum(self,typ):

        typ = typ
        state = lectura_estado(typ)
        ide = lectura_ide(typ)
        mag = 'porcentage'
        if state == 'active' and humi == True:
            value = hum_data()
            return Sensor(typ,ide,mag,value,state).toJason()

    def create_rad(self,typ):

        typ = typ
        state = lectura_estado(typ)
        ide = lectura_ide(typ)
        mag = 'W/m2'
        if state == 'active' and radi == True:
            value = "{0:.3f}".format(adc0.value*1800.0)
            return Sensor(typ,ide,mag,value,state).toJason()

    def create_dir(self,typ):

        direction = ""
        valoradc1 = adc1.value*3.3
        typ = typ
        state = lectura_estado(typ)
        ide = lectura_ide(typ)

        if   valoradc1 == 0.1:
            direction = 'ESTE'
        elif valoradc1 >= 0.2 and valoradc1 <0.4:
            direction =  'SUR-ESTE'
        elif valoradc1 >= 0.4 and valoradc1 <0.7:
            direction =  'SUR'
        elif valoradc1 >= 0.7 and valoradc1 <1.2:
            direction =  'NOR-ESTE'
        elif valoradc1 >= 1.2 and valoradc1 <1.8:
            direction =  'SUR-OESTE'
        elif valoradc1 >= 1.8 and valoradc1 <2.3:
            direction =  'NORTE'
        elif valoradc1 >= 2.4 and valoradc1 <2.7:
            direction =  'NOR-OESTE'
        elif valoradc1 >= 2.7:
            direction =  'OESTE'
        mag = 'Cardinal-point'
        if state == 'active' and dire == True:
            value = direction
            return Sensor(typ,ide,mag,value,state).toJason()

    def create_vel(self,typ):

        typ = typ
        state = lectura_estado(typ)
        ide = lectura_ide(typ)
        mag = 'Km/h'
        if state == 'active' and velo == True:
            value = "{0:.2f}".format(speed_data())
            return Sensor(typ,ide,mag,value,state).toJason()

    def create_plu(self,typ):

        typ = typ
        state = lectura_estado(typ)
        ide = lectura_ide(typ)
        mag = 'mm'
        if state == 'active' and pluv == True:
            value = rain_data()
            return Sensor(typ,ide,mag,value,state).toJason()    
        
    def createSensor(self,sensorType):
        if sensorType == 'tem':            
            return self.create_temp('tem') # depende del archivo de entrada  
        elif sensorType == 'hum':
            return self.create_hum('hum') 
        elif sensorType == 'vel':
            return self.create_vel('vel') 
        elif sensorType == 'dir':
            return self.create_dir('dir')
        elif sensorType == 'plu':
            return self.create_plu('plu') 
        elif sensorType == 'rad':
            return self.create_rad('rad')  

############ metodos fuera de clases#############

def lectura_estado(tipo):

    with open('conf_l.json') as file:
        datajson = json.load(file)
        for sensor in datajson['sensors']:
            if sensor['type'] == tipo:
                return sensor['state']

def lectura_ide(tipo):

    with open('conf_l.json') as file:
        datajson = json.load(file)
        for sensor in datajson['sensors']:
            if sensor['type'] == tipo:
                return sensor['sensor-id']


def id_node():
     with open('conf_l.json') as file:
        datajson = json.load(file)
        return datajson['node-id']

am2315h = 'off'
am2315t = 'off'
pluvio = 'off'
radia = 'off'
wdirec = 'off'
wspeed = 'off'


while True:

    msg = subscribe.simple("req_l", hostname="192.168.4.1")
    datos = msg.payload
    datum = datos.decode('ASCII')
    entrada = json.loads(datum)
    hoy= datetime.today()
    formatdate= "%x-%X"
    now = hoy.strftime(formatdate)
    nuevo_json = {}
    nuevo_json['node-id']= id_node()
    nuevo_json['date'] = now
    nuevo_json['sensors'] =[]

    for sensor in entrada['sensors']:
        if sensor['sensor-id'] == "Temperature":
            temp = True
        if sensor['sensor-id'] == "Humidity":
            humi = True
        if sensor['sensor-id'] == "Velocity":
            velo = True
        if sensor['sensor-id'] == "Direction":
            dire = True
        if sensor['sensor-id'] == "Radiation":
            radi = True
        if sensor['sensor-id'] == "Pluviometer":
            pluv = True
        else:
            pluv = False
    
        with open('conf_l.json') as file:
            datajson = json.load(file)
            for sensor in datajson['sensors']:
                estacion = ReadSensor().createSensor(sensor['type'])
                if estacion != None:
                    nuevo_json['sensors'].append(json.loads(estacion))
            print(json.dumps(nuevo_json, indent=4))
            sleep(5)  

    # if entrada['request'] == 'info':
    #     with open('conf_l.json') as file:
    #         datajson = json.load(file)
    #         for sensor in datajson['sensors']:
    #             estacion = CreateState().createSensorState(sensor['type'])
    #             nuevo_json['sensors'].append(json.loads(estacion))
    #     print(json.dumps(nuevo_json, indent=4))
        #publicar por sta_l
        