import paho.mqtt.subscribe as subscribe
import paho.mqtt.publish as publish

msg = subscribe.simple("mensaje", hostname="192.168.4.1")
publish.single("payload_test_piico",msg, hostname="test.mosquitto.org")

