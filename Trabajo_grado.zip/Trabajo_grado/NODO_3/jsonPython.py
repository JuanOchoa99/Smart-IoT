

from collections import OrderedDict 
import json 
import os 
import argparse 
import sys 
from datetime import date 
from datetime import datetime


#today = date.today()
#now = datetime.now()
#print (today)
#print (now)
attributes ={
"sensor-id" : "-",
"node-id"   : "-",
"gate-id"   : "-",
"date"      : "-",
"value"     : "-",
"magnitude" : "-",
"gps"       : "-",
"network-id": "-",
"protocol"  : "-"
}


attributes2 ={
"3sensor-id" : "-",
"3node-id"   : "-",
"3gate-id"   : "-",
"3date"      : "-",
"3value"     : "-",
"3magnitude" : "-",
"3gps"       : "-",
"3network-id": "-",
"3protocol"  : "-"
}





#print y
#y=json.loads(x)


#ayuda
parser = argparse.ArgumentParser()
parser.add_argument("-p"   , help=":sending protocol")
parser.add_argument("-n"   , help=":node address")
parser.add_argument("-s"   , help=":sensor name")
parser.add_argument("-v"   , help=":value")
parser.add_argument("-m"   , help=":sensor magnitude")
parser.add_argument("-net" , help=":network name")
parser.add_argument("-g"   , help=":gateway address")
parser.add_argument("-gps" , help=":global positioning system")
parser.add_argument("-d"   , help=":date")



args= parser.parse_args()

if args.p=="zigbee":
        if args.p:
	        print "sending protocol:",args.p
	        attributes2["3protocol"]=args.p
        if args.n:
	        print "the node address is:",args.n
	        attributes2["3node-id"]=args.n
        if args.s:
	        print "the sensor name is:",args.s
	        attributes2["3sensor-id"]= args.s

        if args.v:
	        print "the value is:",args.v
	        attributes2["3value"]= args.v

        if args.m:
	        print "the magnitude is:",args.m
	        attributes2["3magnitude"]=args.m

        if args.net:
                print "the network name is:",args.net
                attributes2["3network-id"]=args.net

        if args.g:
                print "the gateway address is:",args.g
                attributes2["3gate-id"]=args.g

        if args.gps:
                print "the global positioning system is:",args.gps
                attributes2["3gps"]=args.gps

        if args.d:
                print "the date is:",args.d
                attributes2["3date"]=args.d
else:
        if args.p:
	        print "sending protocol:",args.p
	        attributes["protocol"]=args.p
        if args.n:
	        print "the node address is:",args.n
	        attributes["node-id"]=args.n
        if args.s:
	        print "the sensor name is:",args.s
	        attributes["sensor-id"]= args.s

        if args.v:
	        print "the value is:",args.v
	        attributes["value"]= args.v

        if args.m:
	        print "the magnitude is:",args.m
	        attributes["magnitude"]=args.m

        if args.net:
                print "the network name is:",args.net
                attributes["network-id"]=args.net

        if args.g:
                print "the gateway address is:",args.g
                attributes["gate-id"]=args.g

        if args.gps:
                print "the global positioning system is:",args.gps
                attributes["gps"]=args.gps

        if args.d:
                print "the date is:",args.d
                attributes["date"]=args.d

datajson = json.dumps(attributes, indent=4,separators=(',',':'),sort_keys=True)
datajson2 = json.dumps(attributes2, indent=4,separators=(',',':'),sort_keys=True)

if args.p == "bluetooth":
	send= "python blue_send.py -json '%s'" % datajson
#	send = "mosquitto_pub -h 192.168.1.79 -t bluetooth -m '%s'" % datajson
        os.system(send)

if args.p == "zigbee":
	send = "python xbee_send.py -json '%s'" % datajson2
        os.system(send)


if args.p == "wifi":
	send = "mosquitto_pub -h 192.168.43.144 -t wifi -m '%s'" % datajson
	os.system(send)


#send= "python prueb.py -data '%s'" % datajson
#os.system(send)
#print datajson


#x["id_sensor"]="Temperatura"


#allsites=[x]
#sort_order = ['id_sensor', 'id_nodo', 'id_gatew', 'fecha','valor','Magnitud','GPS']
#allsites_ordered = [OrderedDict(sorted(item.iteritems(), key=lambda (k, v): sort_order.index(k))) 
#			for item in allsites]

#matriz= json.dumps(x, indent=4, separators=(',', ': '))
#print matriz

#mensaje = "mosquitto_pub -h 172.17.27.170 -t Linux -m '%s'" % matriz
#os.system(mensaje)

