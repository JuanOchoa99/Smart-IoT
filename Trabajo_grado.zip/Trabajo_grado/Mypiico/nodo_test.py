import json

def wifi_update():

  network_names = []
  passwords = []

  with open('redes.json') as file:
      networks = json.load(file)
      for network in networks:
        network_names.append(network)
        #print(network_names)

  with open('passwords.json') as file:
      passes = json.load(file)
      for pas in passes:
        passwords.append(pas)
        #print(passwords)

  with open('conf_l.json') as file:
    datajson = json.load(file)

  def CreateWifiConfig(SSID, password):

      config_lines = [
      '\n',
      'network={',
      '\tssid="{}"'.format(SSID),
      '\tpsk="{}"'.format(password),
      '\tkey_mgmt=WPA-PSK',
      '}'
      ]

      config = '\n'.join(config_lines)
      print(config)

      with open("wpa_supplicant.conf", "a+") as wifi:
          wifi.write(config)

      print("Wifi config added")

  for net in datajson['interfaces']:
      if net['type'] == 'wifi':
          SSID = net['ssid']
          PASS = net['psk']


  if SSID in network_names:
      if PASS not in passwords:
        passwords.append(PASS)
        with open('passwords.json', 'w') as file:
          json.dump(passwords, file, indent=4)
        CreateWifiConfig(SSID,PASS)
        #aqui va la copia al wpa_supplicant de la raspberry 
  elif SSID not in network_names:

    passwords.append(PASS)
    network_names.append(SSID)
    with open('redes.json', 'w') as file:
      json.dump(network_names, file, indent=4)
    with open('passwords.json', 'w') as file:
      json.dump(passwords, file, indent=4)
    CreateWifiConfig(SSID,PASS)
    #aqui va la copia al wpa_supplicant de la raspberry 


wifi_update()






