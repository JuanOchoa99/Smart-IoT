import argparse
import json
import sys
import paho.mqtt.client as mqtt
from datetime import date, datetime, time, timedelta
import threading
import time
import csv
#import csvFile
import paho.mqtt.publish as publish

hostname = ""
puerto = 0  
indPublicador = False

def json_decode(data):  
    string_data = data.decode('ASCII')
    json_data = json.loads(string_data)
    return json_data

# Modo escucha
class ConexionMqtt: 
    def subscriptor(self, hostSub, puertoSub):
        client = mqtt.Client()
        client.on_connect = on_connect
        client.on_message = on_message
        print("hostname= ",hostSub,"puerto= ",puertoSub)
        client.connect(host=hostSub, port=puertoSub)
        #client.loop()
        client.loop_forever()
# publica sen_p
class ConexionPub: 
    def publicadorMas(self, topicoPub, mensajePub):
        
        hostPub = 'test.mosquitto.org'
        puertoPub = 1883
        while indPublicador == True:
            service = mqtt.Client('Gateway_piicoPub') 
            service.connect(host= hostPub, port=puertoPub)
            topic = topicoPub
            mensaje = mensajePub
            service.publish(topic, json.dumps(mensaje))

# publica sta_p
class ConexionSta: 
    def publicador(self, topicoPubSta, mensajePubSta):
    
        hostPubSta = 'test.mosquitto.org'
        puertoPubSta = 1883
        service = mqtt.Client('Gateway_piicoPub') 
        service.connect(host= hostPubSta, port=puertoPubSta)
        topic = topicoPubSta
        mensaje = mensajePubSta
        print(topic,mensaje,hostPubSta)
        service.publish(topic, json.dumps(mensaje))

def on_connect(client, userdata, flags, rc): 
    client.subscribe([('sta_l', 2),('sen_l', 2)]) # topicos locales de respuesta del nodo

def on_message(client, userdata, message):
    
    brokerPub = ConexionPub()
    brokerPubSta = ConexionSta()
    global indPublicador
    topico = message.topic
    json_resultado = json_decode(message.payload)
    #print(topico, json.dumps(json_resultado, indent = 2))
    
    #print(json.dumps(json_resultado))
    if topico == 'sta_l':
        datum = []
        datum.append(json.loads(json_resultado))
        hoy= datetime.today()
        formatdate= "%x-%X"
        now = hoy.strftime(formatdate)
        nuevo_json = {}
        nuevo_json['Gateway-id'] = "Gateway_1"
        nuevo_json['date'] = now
        nuevo_json['station-data'] = datum
        # nuevo_json['estacion-data'].append(json_resultado)
        mensaje = json.dumps(nuevo_json, indent = 2)
        publish.single("sta_p", mensaje, hostname="mqtt.eclipse.org")
        print(mensaje)
        
    elif topico == 'sen_l':
        datos = []
        datos.append(json_resultado)
        hoy= datetime.today()
        formatdate= "%x-%X"
        now = hoy.strftime(formatdate)
        nuevo_json = {}
        nuevo_json['Gateway-id'] = "Gateway_1"
        nuevo_json['date'] = now
        nuevo_json['station-data'] = datos
        sensors_data = json.dumps(nuevo_json, indent = 2)
        publish.single("sen_p", sensors_data, hostname="mqtt.eclipse.org")
        print(sensors_data)
 
        with open('data.txt', 'w') as outfile:
            json.dump(sensors_data, outfile, sort_keys = True, indent = 4, ensure_ascii = False)
  


def main():

    
    hostname = '192.168.4.1'
    puerto = 1883
    broker = ConexionMqtt()
    threadSuscriptor = threading.Thread(name="Subscriptor", target=broker.subscriptor, args=(hostname, puerto))
    threadSuscriptor.start()


if  __name__ ==  '__main__':
    main()



