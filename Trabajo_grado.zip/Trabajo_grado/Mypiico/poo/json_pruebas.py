import json

with open("conf_l.json","r") as read_file:
    data = json.load(read_file) # retorna un diccionario

print(data['sensors'])