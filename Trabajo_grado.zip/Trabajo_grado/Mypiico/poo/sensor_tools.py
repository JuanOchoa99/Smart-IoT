import json
import time
from datetime import date, datetime, time, timedelta

#temperature = False

class Sensor():
    def __init__(self,typ,ide,mag,val,sta):
        self.__ide=ide
        self.__typ=typ
        self.__mag=mag
        self.__val=val
        self.__sta = sta
    
    def getIde(self):
        return self.__ide
    
    def setIde(self,ide):
        self.__ide=ide    
    
    def getTyp(self):
        return self.__typ
    
    def setTyp(self,typ):
        self.__typ=typ      
    
    def getSta(self):
        return self.__sta
    
    def setSta(self,sta):
        self.__sta=sta   

    def getMag(self):
        return self.__mag
    
    def setMag(self,mag):
        self.__mag=mag
    
    def getVal(self):
        return self.__val
    
    def setVal(self,val):
        self.__val=val
        
    def toJason(self):
        self.__attributes = {"type" : "-","sensor-id" : "-","value" : "-", "magnitude" : "-","state":"-"}
        self.__attributes["type"]=self.getTyp()
        self.__attributes["sensor-id"]=self.getIde()
        self.__attributes["value"]=self.getVal()
        self.__attributes["magnitude"]=self.getMag()
        self.__attributes["state"]=self.getSta()
        self.__datajson = json.dumps(self.__attributes, indent=4,separators=(',',':'),sort_keys=False)
        return self.__datajson
    
    def __str__(self):           
        return self.toJason()


# am2315 = Sensor("tem","temperature","Celsius","0.0C")

# am2315.setVal("25")

# print(am2315.getMag())


# print(am2315.getMag() == "Celsius")

class ReadSensor():
    def __init__(self):
        self.__sensors=[]
    
    def getSensors(self,sensors):
        for s in sensors:   
            if s == 'all':
                self.createListAllSensor()                
                return self.__sensors   
        self.__sensors=[]
        for i in range(len(sensors)):   
            self.__sensors.append(json.loads(self.createSensor(sensors[i])))
        return self.__sensors 
    
    def createListAllSensor(self):
        self.__sensors=[
            json.loads(self.createSensor('tem')),
            json.loads(self.createSensor('hum')),
            json.loads(self.createSensor('vel')),
            json.loads(self.createSensor('dir')),
            json.loads(self.createSensor('plu')),
            json.loads(self.createSensor('rad'))]
    
    def create_temp(self,typ):

        # leer sensor de temperatura
        
        #leer del archivo de configuracion si el sensor = active
        typ = typ
        state = lectura_estado(typ)
        ide = lectura_ide(typ)
        mag = 'Celsius'
        if state == 'active':
            value = 10.0
            return Sensor(typ,ide,mag,value,state).toJason()

    def create_hum(self,typ):

        # leer sensor de temperatura
        
        #leer del archivo de configuracion si el sensor = active
        typ = typ
        state = lectura_estado(typ)
        ide = lectura_ide(typ)
        mag = 'porcentage'
        if state == 'active':
            value = 10.0
            return Sensor(typ,ide,mag,value,state).toJason()

    def create_rad(self,typ):

        # leer sensor de temperatura
        
        #leer del archivo de configuracion si el sensor = active
        typ = typ
        state = lectura_estado(typ)
        ide = lectura_ide(typ)
        mag = 'W/m2'
        if state == 'active':
            value = 10.0
            return Sensor(typ,ide,mag,value,state).toJason()

    def create_dir(self,typ):

        # leer sensor de temperatura
        
        #leer del archivo de configuracion si el sensor = active
        typ = typ
        state = lectura_estado(typ)
        ide = lectura_ide(typ)
        mag = 'Cardinal-point'
        if state == 'active':
            value = 'Norte'
            return Sensor(typ,ide,mag,value,state).toJason()

    def create_vel(self,typ):

        # leer sensor de temperatura
        
        #leer del archivo de configuracion si el sensor = active
        typ = typ
        state = lectura_estado(typ)
        ide = lectura_ide(typ)
        mag = 'Km/h'
        if state == 'active':
            value = 10
            return Sensor(typ,ide,mag,value,state).toJason()

    def create_plu(self,typ):

        # leer sensor de temperatura
        
        #leer del archivo de configuracion si el sensor = active
        typ = typ
        state = lectura_estado(typ)
        ide = lectura_ide(typ)
        mag = 'mm'
        if state == 'active':
            value = 10
            return Sensor(typ,ide,mag,value,state).toJason()    
        
    def createSensor(self,sensorType):
        if sensorType == 'tem':
            #return Sensor('tem', 'Temperature', 'Celsius', '0.0',"active").toJason()   funcion create sens tem   
            return self.create_temp('tem') # depende del archivo de emtrada  

        elif sensorType == 'hum':
            return self.create_hum('hum') 
        elif sensorType == 'vel':
            return self.create_vel('vel') 
        elif sensorType == 'dir':
            return self.create_dir('dir')
        elif sensorType == 'plu':
            return self.create_plu('plu') 
        elif sensorType == 'rad':
            return self.create_rad('rad')  


def lectura_estado(tipo):

    with open('conf_l.json') as file:
        datajson = json.load(file)
        for sensor in datajson['sensors']:
            if sensor['type'] == tipo:
                return sensor['state']

def lectura_ide(tipo):

    with open('conf_l.json') as file:
        datajson = json.load(file)
        for sensor in datajson['sensors']:
            if sensor['type'] == tipo:
                return sensor['sensor-id']

nodeid = "estacion_1"


def main():

    hoy= datetime.today()
    formatdate= "%x-%X"
    now = hoy.strftime(formatdate)
    nuevo_json = {}
    nuevo_json['node-id']= nodeid
    nuevo_json['date'] = now
    nuevo_json['sensors'] =[]



    with open('conf_l.json') as file:
        datajson = json.load(file)
        while True:
            for sensor in datajson['sensors']:
                estacion = ReadSensor().createSensor(sensor['type'])
                if estacion != None:
                    nuevo_json['sensors'].append(json.loads(estacion))
            print(json.dumps(nuevo_json, indent=4))
        

main()








