

class Auto:
    marca = ""
    modelo = 0
    placa = ""


taxi = Auto()

print(taxi.modelo)

class Ropa: # esta puede ser
    def __init__(self):
        self.marca = "ralph_lauren"
        self.talla = "XXL"
        self.color = "rojo"

chaqueta = Ropa()
pantalon = Ropa()
pantalon.talla = "L"
pantalon.color = "azul"
pantalon.marca = "abril"


print(pantalon.marca,chaqueta.talla)

class Calculadora:
    def __init__(self, n1, n2):
        self.suma = n1 + n2
        self.resta = n1 - n2
        self.producto = n1 * n2
        self.division = n1 / n2

operacion = Calculadora(5, 3)
print(operacion.division)

#########funciones para atributos

class Persona:
    edad = 31
    nombre = "fernando"
    pais = "brasil"

ingeniero = Persona()

print("la edad es", ingeniero.edad)
print("la edad es", getattr(ingeniero,'edad'))
print("el ingeniero tiene una apellido?", hasattr(ingeniero,'apellido'))
print("antes era", ingeniero.nombre)
setattr(ingeniero,'nombre','carlos')
print("ahora se llama", ingeniero.nombre)
delattr(Persona,'pais')
#print(ingeniero.pais) # salta error porque se elimino ese atributo dentro de la clase

############################funciones con atributos

class Otra_persona: 
    pass
    def __init__(self, nombre, edad):
        self.nombre = nombre
        self.edad = edad

    def descripcion(self):
        return "{} tiene {} años".format(self.nombre,self.edad)

    def comentario(self, frase):
        return "{} dice: {}".format(self.nombre, frase)

doctor = Otra_persona("jairo", 59)
print(doctor.descripcion())
print(doctor.comentario("hola como vas?"))

############################################## Constructores

class Email:
    def __init__(self):
        self.enviado = False

    def enviar_correo(self):
        self.enviado = True

mi_correo = Email()

print(mi_correo.enviado)
mi_correo.enviar_correo()
print(mi_correo.enviado)

###########################################Herencia

class Pokemon:
    pass

    def __init__(self, nombre, tipo):
        self.nombre = nombre
        self.tipo = tipo

    def descripcion(self):
        return "{} es un pokemon de tipo {}".format(self.nombre,self.tipo)

class Pikachu (Pokemon):
    def ataque(self, tipo_ataque):
        return "{} tipo de ataque {}".format(self.nombre, tipo_ataque)

class Charmander(Pokemon):
    def ataque(self, tipo_ataque):
        return "{} tipo de ataque {}".format(self.nombre, tipo_ataque)


nuevo_pokemon = Pikachu("pedro","electrico")
print(nuevo_pokemon.descripcion())
print(nuevo_pokemon.ataque("impact-trueno"))

########################################################

class Otra_calculadora:
    def __init__(self, numero):
        self.n = numero
        self.datos = [0 for i in range(numero)]

    def ingresar_dato(self):
        self.datos = [int(input("Ingresar datos" + str(i+1) + "=")) for i in range(self.n)]

class op_basicas(Otra_calculadora):

    def __init__(self):
        Otra_calculadora.__init__(self,2)
    
    def suma1(self):
        a, b, = self.datos
        s = a + b
        print("el resultado es: ", s)

    def resta1(self):
        a, b, = self.datos
        r = a - b
        print("el resultado es: ", r)

class raiz(Otra_calculadora):
    def __init__(self):
        Otra_calculadora.__init__(self,1)

    def raiz_cuadrada(self):
        import math
        a, = self.datos
        print("el resultado es: {0:1f}".format(math.sqrt(a)))

ejemplo = raiz()
print(ejemplo.ingresar_dato())
print(ejemplo.raiz_cuadrada())
