from collections import OrderedDict
import json
import os
import sys
import argparse
import smbus
import time
import Adafruit_DHT
from datetime import date, datetime, time, timedelta
import calendar
import time
import math
import traceback
hoy= datetime.today()
formatdate= "%x-%X"
now = hoy.strftime(formatdate)
sensor = Adafruit_DHT.DHT11
DHT11_pin = 22

print(str(now))

parser = argparse.ArgumentParser()
parser.add_argument("-tem"   , help=":Protocol to send")
parser.add_argument("-hum"   , help=":Protocol to send")
parser.add_argument("-rad"   , help=":Protocol to send")
args= parser.parse_args()

DEVICE     = 0x23 # Default device I2C address

POWER_DOWN = 0x00 # No active state
POWER_ON   = 0x01 # Power on
RESET      = 0x07 # Reset data register value

CONTINUOUS_LOW_RES_MODE = 0x13
CONTINUOUS_HIGH_RES_MODE_1 = 0x10
CONTINUOUS_HIGH_RES_MODE_2 = 0x11
ONE_TIME_HIGH_RES_MODE_1 = 0x20
ONE_TIME_HIGH_RES_MODE_2 = 0x21
ONE_TIME_LOW_RES_MODE = 0x23


bus = smbus.SMBus(1)  

nodeid="nodo1"

def convertToNumber(data):
  
        result=(data[1] + (256 * data[0])) / 1.2
        return (result)

def readLight(addr=DEVICE):
  
        data = bus.read_i2c_block_data(addr,ONE_TIME_HIGH_RES_MODE_1)
        return convertToNumber(data)


def conditions():
    humidity, temperature = Adafruit_DHT.read_retry(sensor, DHT11_pin)
    if args.tem:
        env='python3 testjson2.py -p ' + args.tem +' -n ' + nodeid + ' -s Temperature -v ' + '{0:0.1f}'.format(temperature) + $
        os.system(env) 


    if args.hum:
        env='python3 testjson2.py -p '+ args.hum +' -n '+ nodeid +' -s Humidity -v '+'{0:0.1f}'.format(humidity) + ' -m percen$
        os.system(env)

    if args.rad:

       lightLevel= readLight()
        time.sleep(1)
        env='python3 testjson2.py -p '+ args.rad +' -n '+ nodeid +' -s Iluminacion -v '+ format(lightLevel,'.2f') +' -m lux -d$
        os.system(env)

def main():
    while True:
        hoy = datetime.today()
        formatdate = "%x-%X"
        now = hoy.strftime(formatdate)
        conditions()
        time.sleep(60)

if __name__=="__main__":
    main()





