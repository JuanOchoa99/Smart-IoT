import json
import paho.mqtt.client as mqtt
import sys
import os
import time
from datetime import date, datetime, time, timedelta
import paho.mqtt.subscribe as subscribe
import paho.mqtt.publish as publish
import calendar
from gpiozero import MCP3008
from gpiozero import Button
import board
import busio
import adafruit_am2320
import math
import traceback
from air_speed import speed_data


with open('conf_l.json') as file:
    data = json.load(file)
    periodo_muestreo = int(data['sampling-frequency'])
    nodeid = data['node-id']


msg = subscribe.simple("req_l", hostname="192.168.4.1")
datos = msg.payload
datum = datos.decode('ASCII')
datajson = json.loads(datum)



for sensor in datajson['sensors']:
    if sensor['sensor-id'] == "Temperature":
        temp = True
    if sensor['sensor-id'] == "Humidity":
        humi = True
    if sensor['sensor-id'] == "Velocity":
        velo = True
    if sensor['sensor-id'] == "Direction":
        dire = True
    if sensor['sensor-id'] == "Radiation":
        radi = True
    if sensor['sensor-id'] == "Pluviometer":
        pluv = True
    else:
        pluv = False



####### variable cantidad de agua
BUCKET_SIZE 	= 0.2794
rain_count      = 0
water_amount	= 0



# Definicion de sensores necesarios
i2c = busio.I2C(board.SCL, board.SDA)
sensor = adafruit_am2320.AM2320(i2c)
adc1 = MCP3008 (channel=1)
adc0 = MCP3008 (channel=0)
rain_sensor = Button(6)


def bucket_tipped():
	global rain_count
	global water_amount
	rain_count   = rain_count + 1
	water_amount = rain_count * BUCKET_SIZE


rain_sensor.when_pressed = bucket_tipped


def reset_rainfall():
	global rain_count
	rain_count   = 0


def sensar(delay):
    
    direction = ""
    temperature = sensor.temperature
    radiation=("{0:.3f}".format(adc0.value*1800.0))
    lectura_tem = '{0}C'.format(temperature)
    humidity = sensor.relative_humidity
    lectura_hum = '{0}%'.format(humidity)
    (mean, maxim) = speed_data()
    rain_sensor.when_pressed = bucket_tipped
    lluvia = water_amount
    valoradc1 = adc1.value*3.3

    if   valoradc1 == 0.1:
        direction = 'ESTE'
    elif valoradc1 >= 0.2 and valoradc1 <0.4:
        direction =  'SUR-ESTE'
    elif valoradc1 >= 0.4 and valoradc1 <0.7:
        direction =  'SUR'
    elif valoradc1 >= 0.7 and valoradc1 <1.2:
        direction =  'NOR-ESTE'
    elif valoradc1 >= 1.2 and valoradc1 <1.8:
        direction =  'SUR-OESTE'
    elif valoradc1 >= 1.8 and valoradc1 <2.3:
        direction =  'NORTE'
    elif valoradc1 >= 2.4 and valoradc1 <2.7:
        direction =  'NOR-OESTE'
    elif valoradc1 >= 2.7:
        direction =  'OESTE'
    time.sleep(delay)
    return(lectura_tem,lectura_hum,radiation,direction,mean,maxim,water_amount)

while True:
    
    hoy= datetime.today()
    formatdate= "%x-%X"
    now = hoy.strftime(formatdate)
    (tem,hum,radiation,wind,promedio,maximo,water_amount) = sensar(periodo_muestreo)
    nuevo_json = {}
    nuevo_json['node-id']= nodeid
    nuevo_json['date'] = now
    nuevo_json['sensors'] =[]

    if temp == True:
        nuevo_json['sensors'].append({
                                "type":"tem",
                                "sensor-id":"temperature",
                                "value":tem,
                                "magnitude":"Celsius" })
    if humi == True:
        nuevo_json['sensors'].append({
                                "type":"hum",
                                "sensor-id":"Humidity",
                                "value":hum,
                                "magnitude":"%" })
    if radi == True:
        nuevo_json['sensors'].append({
                                "type":"rad",
                                "sensor-id":"radiation",
                                "value":radiation,
                                "magnitude":"W/m2" })
    if dire == True:
        nuevo_json['sensors'].append({
                                "type":"dir",
                                "sensor-id":"wind-direction",
                                "value":wind,
                                "magnitude":"cardinal-point" })
    if velo == True:
        nuevo_json['sensors'].append({
                                "type":"vel",
                                "sensor-id":"wind-speed",
                                "mean-value":'{0:.2f}'.format(promedio),
                                "max-value":'{0:.2f}'.format(maximo),
                                "magnitude":"Km/h" })
    if pluv == True:
        nuevo_json['sensors'].append({
                                "type":"plu",
                                "sensor-id":"pluviometer",
                                "value":'{0:.2f}'.format(water_amount),
                                "magnitude":"mm/h" })

    #print("-------SEN_l---------\n",json.dumps(nuevo_json['sensors']))
    print(json.dumps(nuevo_json))
    string = json.dumps(nuevo_json, indent=2)
    publish.single("sen_l", string, hostname="192.168.4.1")
