from configparser import ConfigParser
import shutil
import os

original = r'wifi.ini'
target = r'hostapd.conf'
nOriginal = r'dns.ini'
target1 = r'dnsmasq.conf'
base = r'dhcpcd.ini'
destino = r'dhcpcd.conf'

file1 = 'dns.ini'
config1 = ConfigParser()
config1.read(file1)

file = 'wifi.ini'
config = ConfigParser()
config.read(file)

def basico(name, passwd, channel):
    config.set('configuration', 'ssid',name)
    config.set('configuration', 'wpa_passphrase',passwd)
    config.set('configuration', 'channel',channel)
    with open(file, 'w') as configfile:
        config.write(configfile)
    shutil.copy(original, target)
    a_file = open("hostapd.conf", "r+")
    lines = a_file.readlines()
    a_file.close()
    del lines[0]
    new_file = open("hostapd.conf", "w+")
    for line in lines:
        c = line.replace(" ","")
        new_file.write(c)
    new_file.close()
    os.system("sudo cp hostapd.conf /etc/hostapd/hostapd.conf")
    
def avanzado(current, address, dirIni, dirFin, time):
    tiempo = (time + "h")
    netmask = "255.255.255.0"
    direccion = ("/gw.wlan/" + address)
    original = current + "/24"
    nueva = address + "/24"
    rango = (dirIni+","+dirFin+"," + netmask +","+tiempo)
    config1.set('rango','dhcp-range',rango)
    config1.set('rango','address',direccion)
    with open(file1, 'w') as configfile:
        config1.write(configfile)
    shutil.copy(nOriginal,target1)
    
    b_file = open("dnsmasq.conf", "r+")
    lineas = b_file.readlines()
    b_file.close()
    del lineas[0]  

    new1_file = open("dnsmasq.conf", "w+")
    for linea in lineas:
        p = linea.replace(" ","")
        new1_file.write(p)
    new1_file.close()
    os.system("sudo cp dnsmasq.conf /etc/dnsmasq.conf")
    
    c_file = open("dhcpcd.ini", "r+")
    lineas = c_file.readlines()
    c_file.close()

    new_file = open("dhcpcd.ini", "w+")
    for linea in lineas:
        p = linea.replace(original,nueva)
        new_file.write(p)
    new_file.close()
    shutil.copy(base, destino) 
    os.system("sudo cp dhcpcd.conf /etc/dhcpcd.conf")

    

def  menu():
    print("Selecciona el modo de configuracion del Access Point")
    choice = input("A: Modo básico B: Modo avanzado: ")
    
    if choice == 'A':
        name = input("Nombre de la red Wifi: ")
        passwd = input("Contraseña: ")
        channel = input("Canal: ")
        basico(name, passwd, channel)
        
    elif choice == 'B':
        name = input("Nombre de la red Wifi: ")
        passwd = input("Contraseña: ")
        channel = input("Canal: ")
        current = input("Ingrese la IP actual del Access Point: ")
        address = input("ingrese la nueva direccion Ip del Access Point: ")
        print("Ingrese el rango de direcciones")
        dirIni = input("Direccion inicio: ")
        dirFin = input("Direccion fin: ")
        time = input("Tiempo de asignacion en horas: ")
        basico(name, passwd, channel)
        avanzado(current, address, dirIni, dirFin, time)
        
menu()
        
        