sudo systemctl start bluetooth
sleep 1
echo -e 'discoverable on' | bluetoothctl
