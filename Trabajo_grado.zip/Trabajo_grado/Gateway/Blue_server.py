import json
import bluetooth
import os
import time

server_sock=bluetooth.BluetoothSocket( bluetooth.RFCOMM )


port = 1
server_sock.bind(("",port))
server_sock.listen(1)

try:

    while True:

        client_sock,address = server_sock.accept()
        
        data = client_sock.recv(1024)
        #print ('%s' % data)
        datos = data.decode('ASCII')
        
        #print (datos)
        
        mensaje = "mosquitto_pub -h 'test.mosquitto.org' -t piico_usb -m '%s'"%datos # al BROKER PUBLICO
        os.system(mensaje)
        #time.sleep(10)
except KeyboardInterrupt:

    client_sock.close()
    server_sock.close()
