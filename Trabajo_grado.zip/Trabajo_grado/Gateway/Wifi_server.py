import paho.mqtt.client as mqtt
import sys
import json
import os
import time

#inicio="clear"
#os.system(inicio)


broker_url = "192.168.4.1"
broker_port = 1883



#def on_connect(client, userdata, flags, rc):
#   print("Connected With Result Code " (rc))

def on_message_from_node(client, userdata, message):

   datos= json.loads(message.payload.decode())
   datos["gate-id"]="Raspberry PI"
   datos["network-id"]="red-1"
   datos["gps"]="usb"
   env= json.dumps(datos, indent=4, separators=( ',', ':'),sort_keys= True)
   print (env)

   dato=str(env)
   #mensaje= "mosquitto_pub -h 'test.mosquitto.org' -t piico_usb -m '%s'" %dato
   #os.system(mensaje)

#def on_message(client, userdata, message):
   #print("Message Recieved from Others: "+message.payload.decode())


client = mqtt.Client()
#client.on_connect = on_connect
#client.on_message = on_message

try:
    client.connect(broker_url, broker_port)
except:
    print ("Error de conexion con Broker")
    print ("cerrando")
    sys.exit()


#lista de topicos

client.subscribe("wifi"     , qos=1)
client.subscribe("bluetooth", qos=1)
client.subscribe("zigbee"   , qos=1)



#recepcion de mensajes
client.message_callback_add("wifi"     , on_message_from_node)
client.message_callback_add("bluetooth", on_message_from_node)
client.message_callback_add("zigbee"   , on_message_from_node)

try:
        client.loop_forever()
        #time.sleep(10)
except KeyboardInterrupt: #ctrl + c
        print ("Cerrando...")

