import time
import serial

ser =serial.Serial('/dev/ttyUSB0', 9600)
counter=0       
      
while 1:
    #ser.write(str.encode('Write counter: %d \n'%(counter)))
    #time.sleep(1)
    #counter += 1
    incoming=ser.readline().strip()
    mensaje = incoming.decode('ASCII')
    print(mensaje)