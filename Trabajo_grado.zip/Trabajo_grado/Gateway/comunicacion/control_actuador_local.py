import json
import os
import sys
import time
import paho.mqtt.publish as publish



config_string = '''
{
    "node-id":"estacion_2",
    "pass":"yuijefwsfmna",
    "date":"datetime.datetime(2016, 4, 8, 11, 43, 54, 920632)",
    "request":"info",
    "actuators":[
        {
            "actuator-id":"Lawn-sprinkler",
            "order":"off"
        }
        
    ]
}
'''
data = json.loads(config_string)
new_string = json.dumps(data, indent=2, sort_keys=False)
publish.single("act_l",new_string, hostname="192.168.4.1")





















