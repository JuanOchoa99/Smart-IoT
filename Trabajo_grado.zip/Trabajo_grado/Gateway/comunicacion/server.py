import argparse
import json
import sys
import paho.mqtt.client as mqtt
from datetime import date, datetime, time, timedelta
import threading
import time
import paho.mqtt.publish as publish


def json_decode(data):  
    string_data = data.decode('ASCII')
    json_data = json.loads(string_data)
    return json_data

# Modo escucha local
class ConexionMqtt: 
    def subscriptor(self, hostSub, puertoSub):
        client = mqtt.Client()
        client.on_connect = on_connect
        client.on_message = on_message
        print("hostname= ",hostSub,"puerto= ",puertoSub)
        client.connect(host=hostSub, port=puertoSub)
        client.loop_forever()

# Modo escucha pública
class MqttPublic:
    def suscripcion(self, host, port):
        client1 = mqtt.Client()
        client1.on_connect = on_connect2
        client1.on_message = on_message2
        print("hostname= ",host,"puerto= ",port)
        client1.connect(host=host, port= port)
        client1.loop_forever()

# topicos locales de respuesta del nodo y escucha del Gateway

def on_connect(client, userdata, flags, rc): 
    client.subscribe([('sta_l', 2),('sen_l', 2)])

# topicos publicos de escucha del Gateway por broker publico

def on_connect2(client1, userdata, flags, rc):
    client1.subscribe([('req_p', 2),('conf_p', 2),('act_p', 2)])

# redireccion de mensajes a los nodos segun topico en broker público

def on_message2(client1, userdata, message1):
 
    topico = message1.topic
    json_resultado = json_decode(message1.payload)
    #print(topico)
  
    if topico == 'act_p':
        mensaje = json.dumps(json_resultado, indent = 2)
        publish.single("act_l", mensaje, hostname="192.168.4.1")
        #print(json.dumps(json_resultado, indent = 2))

    if topico == 'req_p':
        salida = json.dumps(json_resultado, indent = 2)
        publish.single("req_l", salida, hostname="192.168.4.1")
        #print(json.dumps(json_resultado, indent = 2))

    if topico == 'conf_p':
        salida2 = json.dumps(json_resultado, indent = 2)
        publish.single("conf_l", salida2, hostname="192.168.4.1")
        #print(json.dumps(json_resultado, indent = 2))
        
# redireccion de mensajes de los nodos al broker público

def on_message(client, userdata, message):
    
    topico = message.topic
    json_resultado = json_decode(message.payload)
    #print(topico)
    
    #print(json.dumps(json_resultado))
    if topico == 'sta_l':
        datum = []
        datum.append(json.loads(json_resultado))
        hoy= datetime.today()
        formatdate= "%x-%X"
        now = hoy.strftime(formatdate)
        nuevo_json = {}
        nuevo_json['Gateway-id'] = "Gateway_1"
        nuevo_json['date'] = now
        nuevo_json['station-data'] = datum
        mensaje = json.dumps(nuevo_json, indent = 2)
        publish.single("sta_p", mensaje, hostname="mqtt.eclipse.org")
        #print(mensaje)
        
    elif topico == 'sen_l':
        datos = []
        datos.append(json_resultado)
        hoy= datetime.today()
        formatdate= "%x-%X"
        now = hoy.strftime(formatdate)
        nuevo_json = {}
        nuevo_json['Gateway-id'] = "Gateway_1"
        nuevo_json['date'] = now
        nuevo_json['station-data'] = datos
        sensors_data = json.dumps(nuevo_json, indent = 2)
        publish.single("sen_p", sensors_data, hostname="mqtt.eclipse.org")
        #print(sensors_data)
 
        # with open('data.txt', 'w') as outfile:
        #     json.dump(sensors_data, outfile, sort_keys = True, indent = 4, ensure_ascii = False)

def main():

    
    hostname = '192.168.4.1'
    host = 'mqtt.eclipse.org'
    puerto = 1883
    broker = ConexionMqtt()
    broker2 = MqttPublic()
    threadSuscriptor = threading.Thread(name="Subscriptor", target=broker.subscriptor, args=(hostname, puerto))
    threadSuscriptor.start()
    threadPublico = threading.Thread(name="Subscripcion_publica", target =broker2.suscripcion, args=(host, puerto))
    threadPublico.start()

if  __name__ ==  '__main__':
    main()
            