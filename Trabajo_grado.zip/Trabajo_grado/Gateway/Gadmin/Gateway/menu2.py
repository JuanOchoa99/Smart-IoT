from configparser import ConfigParser
import shutil
#import os/home/pi/Documents/Gadmin/Gateway
import sys

#name = sys.argv[1]
#passwd = sys.argv[2]
#channel = sys.argv[3]

original = r'/home/pi/Documents/Gadmin/Gateway/wifi.ini'
target = r'/home/pi/Documents/Gadmin/Gateway/hostapd.conf'
#nOriginal = r'dns.ini'
#target1 = r'dnsmasq.conf'
#base = r'dhcpcd.ini'
#destino = r'dhcpcd.conf'

file1 = 'dns.ini'
config1 = ConfigParser()
config1.read(file1)

file = 'wifi.ini'
config = ConfigParser()
config.read(file)

config.set('configuration', 'ssid',sys.argv[1])
config.set('configuration', 'wpa_passphrase',sys.argv[2])
config.set('configuration', 'channel',sys.argv[3])
with open(file, 'w') as configfile:
    config.write(configfile)
shutil.copy(original, target)
a_file = open("hostapd.conf", "r+")
lines = a_file.readlines()
a_file.close()
del lines[0]
new_file = open("hostapd.conf", "w+")
for line in lines:
    c = line.replace(" ","")
    new_file.write(c)
new_file.close()
