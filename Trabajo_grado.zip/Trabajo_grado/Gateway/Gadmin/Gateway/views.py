from django.shortcuts import render
from django.http import HttpResponse
import datetime
import time
import bluetooth
import sys, string
from configparser import ConfigParser
import shutil
from subprocess import run,PIPE
import socket
from datetime import datetime

Gateway_IP = "192.168.4.1"
passd = "Piico2020*"
chan = "7"
Name = "S-PIICO"

def inicio(request):

    entrada= str(request.POST.get('entrada'))
    if entrada != '0':
        aus = entrada
    return render(request, 'home2.html',{"salida":aus})

def Blue_scan(request):
    devices = []
    nearby_devices = bluetooth.discover_devices(duration=8, lookup_names=True,
                                            flush_cache=True, lookup_class=False)
    num_dev = str(len(nearby_devices))
    for addr, name in nearby_devices:
        dev = str("   {} - {}".format(addr, name))
        devices.append(dev)

    return render(request, 'home.html',{"cantidad":num_dev,"aparatos": devices})
        
def blue_button(request):
    return render(request,'home.html')

def blue_server(request):
    out = run([sys.executable,'/home/pi/Documents/Blue_server.py'],shell=False)
    return render(request,'home.html',{"data": out})

def zigbee_server(request):
    out = run([sys.executable,'/home/pi/Documents/Zigbee_server.py'],shell=False)
    return render(request,'home.html',{"data": out})

def wifi_server(request):
    out = run([sys.executable,'/home/pi/Documents/Wifi_server.py'],shell=False)
    return render(request,'home.html',{"data": out})

def button(request):
    return render(request,'home1.html',{'SSID':Name,'passwd':passd,'channel':chan})

def output(request):

    data=requests.get("https://www.google.com/")
    print(data.text)
    data=data.text
    return render(request,'home1.html',{'data':data})


def external(request):

    original = r'/home/pi/Documents/wifi.ini'
    target = r'/home/pi/Documents/hostapd.conf'
    inp= str(request.POST.get('param'))
    inp1= str(request.POST.get('param1'))
    inp2= str(request.POST.get('param2'))  
    file = '/home/pi/Documents/wifi.ini'
    config = ConfigParser()
    config.read(file)
    config.set('configuration', 'ssid',inp)
    config.set('configuration', 'wpa_passphrase',inp1)
    config.set('configuration', 'channel',inp2)
    with open(file, 'w') as configfile:
        config.write(configfile)
    shutil.copy(original, target)
    a_file = open("/home/pi/Documents/hostapd.conf", "r+")
    lines = a_file.readlines()
    a_file.close()
    del lines[0]
    new_file = open("/home/pi/Documents/hostapd.conf", "w+")
    for line in lines:
        c = line.replace(" ","")
        new_file.write(c)
    new_file.close()
    if inp:
        return render(request,'home1.html',{'SSID':inp,'passwd':inp1,'channel':inp2})
    else:
    #salida = "script ejecutado. SSID: %s PASSWORD: %s, CHANNEL: %s"% (inp,inp1,inp2)
        return render(request,'home1.html',{'SSID':name,'passwd':passd,'channel':chan})

def avanzado(request):
    
    origin = r'/home/pi/Documents/dns.ini'
    target = r'/home/pi/Documents/dnsmasq.conf'
    base = r'/home/pi/Documents/dhcpcd.ini'
    destino = r'/home/pi/Documents/dhcpcd.conf'
    inp3= str(request.POST.get('param3'))
    inp4= str(request.POST.get('param4'))
    inp5= str(request.POST.get('param5'))
    inp6= str(request.POST.get('param6'))
    inp7= str(request.POST.get('param7'))
    inp8= str(request.POST.get('param8'))    
    file = '/home/pi/Documents/dns.ini'
    config = ConfigParser()
    config.read(file)
    #Gateway_IP = inp4
    tiempo = (inp8 + "h")
    netmask = inp7
    direccion = ("/gw.wlan/" + inp4)
    original = inp3 + "/24"
    nueva = inp4 + "/24"
    rango = (inp5+","+inp6+"," + inp7 +","+tiempo)
    config.set('rango','dhcp-range',rango)
    config.set('rango','address',direccion)
    with open(file, 'w') as configfile:
        config.write(configfile)
    shutil.copy(origin,target)
    b_file = open("/home/pi/Documents/dnsmasq.conf", "r+")
    lineas = b_file.readlines()
    b_file.close()
    del lineas[0]
    new_file = open("/home/pi/Documents/dnsmasq.conf", "w+")
    for linea in lineas:
        p = linea.replace(" ","")
        new_file.write(p)
    new_file.close()
    #os.system("sudo cp dnsmasq.conf /etc/dnsmasq.conf")
    c_file = open("/home/pi/Documents/dhcpcd.ini", "r+")
    lineas = c_file.readlines()
    c_file.close()

    new1_file = open("/home/pi/Documents/dhcpcd.ini", "w+")
    for linea in lineas:
        p = linea.replace(original,nueva)
        new1_file.write(p)
    new1_file.close()
    shutil.copy(base, destino) 
    salida = "IP act: %s, New IP: %s, Init: %s, Fin: %s, Mask: %s, Time: %s" % (inp3,inp4,inp5,inp6,inp7,inp8)
    #os.system("sudo cp dhcpcd.conf /etc/dhcpcd.conf")
    return render(request,'home1.html',{'data2':salida})

def scan_wifi(request):
    nodos = []
    net = Gateway_IP
    net1 = net.split('.')
    a = '.'

    net2 = net1[0] + a + net1[1] + a + net1[2] + a
    st1 = 2
    en1 = 25 
    en1 = en1 + 1
    t1 = time.perf_counter()

    def scan(addr):
        s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        socket.setdefaulttimeout(1)
        result = s.connect_ex((addr,22))
        if result == 0:
            return 1
        else :
            return 0

    def run1():
        for ip in range(st1,en1):
            addr = net2 + str(ip)
            if (scan(addr)):
                ver = str(addr + " online")
                nodos.append(ver)
    run1()
    t2 = time.perf_counter()
    total = str(round(t2 - t1, 2)) + " segundos"
    return render(request,'home1.html',{'nodos':nodos, 'tiempo':total})

def zigbee(request):
    
    return render(request,'home2.html')

