from django.contrib import admin
from django.urls import path
from Gateway import views

urlpatterns = [

 path('inicio/',views.inicio),
 path('scan/',views.Blue_scan,name = 'script'),
 path('bluetooth/',views.blue_button),
 path('blue_server/',views.blue_server),
 path('zigbee_server/',views.zigbee_server),
 path('wifi_server/',views.wifi_server),
 path('',views.button),
 path('external/',views.external),
 path('avanzado/',views.avanzado),
 path('wifi_scan/',views.scan_wifi,name = 'script1'),
 path('zigbee/',views.zigbee),
]

