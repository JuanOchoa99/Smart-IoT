import bluetooth

#bd_addr = "B8:27:EB:65:9D:0C"
bd_addr = "B8:27:EB:F3:ED:CD"

port = 1

sock=bluetooth.BluetoothSocket( bluetooth.RFCOMM )
sock.connect((bd_addr, port))

sock.send("Comunicacion via Bluetooth exitosa!!")

sock.close()

