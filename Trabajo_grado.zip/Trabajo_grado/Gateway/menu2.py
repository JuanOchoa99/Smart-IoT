#from configparser import ConfigParser
import shutil
#import os
import sys

#file = 'wifi.ini'
#config = ConfigParser()
#config.read(file)

#config.set('configuration', 'ssid',sys.argv[1])
mensaje = "la red se llama: %s, contrasena: %s en el canal % s" % (sys.argv[1],sys.argv[2],sys.argv[3])
print(mensaje)
