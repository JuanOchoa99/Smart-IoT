#!/bin/bash


ifconfig eth0 up
sleep 1s
dhclient eth0
sleep 1s
modprobe -r dhd
sleep 1s
modprobe dhd op_mode=2
sleep 1s
ifconfig wlan0 192.168.1.35 up
sleep 1s
dnsmasq -C /etc/dnsmasq.conf
sleep 1s
./aproute.sh
sleep 1s
hostapd /etc/hostapd/hostapd.conf -B
sleep 1s
exit

